package com.example.githubapp.sub2.yudha.model

data class UserResponse(
    val items : ArrayList<User>
)