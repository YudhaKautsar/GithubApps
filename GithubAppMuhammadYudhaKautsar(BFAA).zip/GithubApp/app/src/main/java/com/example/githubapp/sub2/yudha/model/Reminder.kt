package com.example.githubapp.sub2.yudha.model

data class Reminder(

    var isReminded: Boolean = false
)
